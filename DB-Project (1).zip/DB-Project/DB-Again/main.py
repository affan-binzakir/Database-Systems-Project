"""
LTHR PK Database Management System - GUI Application
Complete Python Tkinter Frontend for Database Testing
Author: Student Implementation for Database Systems Course
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import pyodbc
import json
from datetime import datetime, date
import pandas as pd
from functools import lru_cache
import threading
from queue import Queue


class LTHRPKDatabaseGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("LTHR PK Database Management System")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')

        # Database connection
        self.connection = None
        self.cursor = None
        self.connection_pool = Queue(maxsize=5)  # Connection pool

        # Cache for frequently accessed data
        self.cache = {}
        self.cache_timeout = 300  # 5 minutes cache timeout
        self.last_refresh = {}

        # Setup GUI
        self.setup_connection_frame()
        self.setup_main_interface()

        # Background refresh thread
        self.refresh_thread = None
        self.stop_refresh = False

    def setup_connection_frame(self):
        """Setup database connection frame"""
        self.conn_frame = ttk.LabelFrame(self.root, text="Database Connection", padding="10")
        self.conn_frame.pack(fill="x", padx=10, pady=5)

        # Connection fields
        ttk.Label(self.conn_frame, text="Server:").grid(row=0, column=0, sticky="w", padx=5)
        self.server_entry = ttk.Entry(self.conn_frame, width=30)
        self.server_entry.insert(0, "localhost")
        self.server_entry.grid(row=0, column=1, padx=5)

        ttk.Label(self.conn_frame, text="Database:").grid(row=0, column=2, sticky="w", padx=5)
        self.db_entry = ttk.Entry(self.conn_frame, width=20)
        self.db_entry.insert(0, "LTHR_PK")
        self.db_entry.grid(row=0, column=3, padx=5)

        ttk.Button(self.conn_frame, text="Connect", command=self.connect_database).grid(row=0, column=4, padx=10)

        self.conn_status = ttk.Label(self.conn_frame, text="Not Connected", foreground="red")
        self.conn_status.grid(row=0, column=5, padx=10)

    def setup_main_interface(self):
        """Setup main interface with notebook tabs"""
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=5)

        # Initialize tabs dictionary for lazy loading
        self.tabs = {}
        self.tab_frames = {}

        # Add tab names
        self.tab_names = ['Dashboard', 'Products', 'Customers', 'Orders', 'Inventory', 'Reports', 'Admin']

        # Create empty frames for each tab
        for tab_name in self.tab_names:
            frame = ttk.Frame(self.notebook)
            self.tab_frames[tab_name] = frame
            self.notebook.add(frame, text=tab_name)

        # Bind tab selection event
        self.notebook.bind('<<NotebookTabChanged>>', self.on_tab_selected)

    def on_tab_selected(self, event):
        """Handle tab selection - lazy loading of tab content"""
        current_tab = self.notebook.select()
        tab_name = self.notebook.tab(current_tab, "text")

        if tab_name not in self.tabs:
            # Load tab content if not already loaded
            setup_method = getattr(self, f'setup_{tab_name.lower()}_tab', None)
            if setup_method:
                setup_method()
                self.tabs[tab_name] = True

    def create_connection(self):
        """Create a new database connection"""
        server = "localhost"
        database = "DB_Project"
        conn_str = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;'
        return pyodbc.connect(conn_str)

    def get_connection(self):
        """Get a connection from the pool or create a new one"""
        try:
            return self.connection_pool.get_nowait()
        except:
            return self.create_connection()

    def return_connection(self, conn):
        """Return a connection to the pool"""
        try:
            self.connection_pool.put_nowait(conn)
        except:
            conn.close()

    @lru_cache(maxsize=32)
    def cached_query(self, query, timeout=300):
        """Cache query results"""
        current_time = datetime.now().timestamp()
        cache_key = query

        if cache_key in self.cache:
            if current_time - self.last_refresh.get(cache_key, 0) < timeout:
                return self.cache[cache_key]

        result = self.execute_query(query)
        if result:
            self.cache[cache_key] = result
            self.last_refresh[cache_key] = current_time
        return result

    def execute_query(self, query, params=None, fetch=True):
        """Execute SQL query with connection pooling"""
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            result = None
            if fetch:
                if query.strip().upper().startswith(('SELECT', 'EXEC', 'WITH')):
                    result = cursor.fetchall()
                else:
                    conn.commit()
                    result = True
            else:
                conn.commit()
                result = True

            cursor.close()
            self.return_connection(conn)
            return result

        except Exception as e:
            if conn:
                self.return_connection(conn)
            messagebox.showerror("Database Error", f"Error executing query:\n{str(e)}")
            return None

    def start_background_refresh(self):
        """Start background refresh thread"""
        if not self.refresh_thread or not self.refresh_thread.is_alive():
            self.stop_refresh = False
            self.refresh_thread = threading.Thread(target=self.background_refresh)
            self.refresh_thread.daemon = True
            self.refresh_thread.start()

    def background_refresh(self):
        """Background refresh of dashboard and other data"""
        while not self.stop_refresh:
            if self.connection:
                current_tab = self.notebook.select()
                tab_name = self.notebook.tab(current_tab, "text")

                if tab_name == "Dashboard":
                    self.refresh_dashboard()
                elif tab_name == "Inventory":
                    self.load_inventory()

            threading.Event().wait(30)  # Refresh every 30 seconds

    def connect_database(self):
        """Connect to SQL Server database"""
        try:
            # Initialize connection pool
            for _ in range(5):
                conn = self.create_connection()
                self.connection_pool.put(conn)

            self.connection = self.get_connection()
            self.cursor = self.connection.cursor()

            self.conn_status.config(text="Connected", foreground="green")
            messagebox.showinfo("Success", "Database connection established!")

            # Start background refresh
            self.start_background_refresh()

            # Load initial data for visible tab
            current_tab = self.notebook.select()
            self.on_tab_selected(None)

        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect to database:\n{str(e)}")
            self.conn_status.config(text="Connection Failed", foreground="red")

    def refresh_dashboard(self):
        """Refresh dashboard with latest data"""
        if not hasattr(self, 'stats_tree'):
            return

        try:
            stats_result = self.cached_query("EXEC SP_GetDashboardStats", timeout=30)

            if stats_result:
                self.root.after(0, self._update_dashboard_ui, stats_result)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh dashboard:\n{str(e)}")

    def _update_dashboard_ui(self, stats_result):
        """Update dashboard UI with new data"""
        # Clear previous stats
        for item in self.stats_tree.get_children():
            self.stats_tree.delete(item)

        # Clear previous orders
        for item in self.recent_orders_tree.get_children():
            self.recent_orders_tree.delete(item)

        # Update statistics
        if stats_result:
            stats = stats_result[0]
            metrics = [
                ("Total Customers", stats[0]),
                ("Total Products", stats[1]),
                ("Today's Orders", stats[2]),
                ("Pending Orders", stats[3]),
                ("Monthly Revenue", f"PKR {stats[4]:,.2f}"),
                ("Low Stock Items", stats[5])
            ]

            for metric, value in metrics:
                self.stats_tree.insert("", "end", values=(metric, value))

            # Update recent orders
            for order in stats_result[1:]:
                self.recent_orders_tree.insert("", "end", values=order)

    def setup_products_tab(self):
        """Products management tab"""
        self.products_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.products_frame, text="Products")

        # Product management sections
        # Add Product Section
        add_frame = ttk.LabelFrame(self.products_frame, text="Add New Product", padding="10")
        add_frame.pack(fill="x", padx=10, pady=5)

        # Product form fields
        ttk.Label(add_frame, text="Product Name:").grid(row=0, column=0, sticky="w", padx=5)
        self.product_name_entry = ttk.Entry(add_frame, width=30)
        self.product_name_entry.grid(row=0, column=1, padx=5)

        ttk.Label(add_frame, text="Description:").grid(row=0, column=2, sticky="w", padx=5)
        self.product_desc_entry = ttk.Entry(add_frame, width=40)
        self.product_desc_entry.grid(row=0, column=3, padx=5)

        ttk.Label(add_frame, text="Category:").grid(row=1, column=0, sticky="w", padx=5)
        self.category_combo = ttk.Combobox(add_frame, width=20)
        self.category_combo.grid(row=1, column=1, padx=5)

        ttk.Label(add_frame, text="Initial Stock:").grid(row=1, column=2, sticky="w", padx=5)
        self.initial_stock_entry = ttk.Entry(add_frame, width=15)
        self.initial_stock_entry.grid(row=1, column=3, padx=5)

        ttk.Label(add_frame, text="Price (PKR):").grid(row=2, column=0, sticky="w", padx=5)
        self.product_price_entry = ttk.Entry(add_frame, width=15)
        self.product_price_entry.grid(row=2, column=1, padx=5)

        ttk.Button(add_frame, text="Add Product", command=self.add_product).grid(row=2, column=2, padx=10)
        ttk.Button(add_frame, text="Load Categories", command=self.load_categories).grid(row=2, column=3, padx=10)

        # Products list
        list_frame = ttk.LabelFrame(self.products_frame, text="Product Catalog", padding="10")
        list_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.products_tree = ttk.Treeview(list_frame,
                                          columns=("ID", "Name", "Category", "Stock", "Price", "Status"),
                                          show="headings", height=12)
        for col in ("ID", "Name", "Category", "Stock", "Price", "Status"):
            self.products_tree.heading(col, text=col)
            self.products_tree.column(col, width=100)

        scrollbar_products = ttk.Scrollbar(list_frame, orient="vertical", command=self.products_tree.yview)
        self.products_tree.configure(yscrollcommand=scrollbar_products.set)

        self.products_tree.pack(side="left", fill="both", expand=True)
        scrollbar_products.pack(side="right", fill="y")

        # Buttons
        buttons_frame = ttk.Frame(self.products_frame)
        buttons_frame.pack(fill="x", padx=10, pady=5)

        ttk.Button(buttons_frame, text="Refresh Products", command=self.load_products).pack(side="left", padx=5)
        ttk.Button(buttons_frame, text="Restock Selected", command=self.restock_product).pack(side="left", padx=5)

    def setup_customers_tab(self):
        """Customer management tab"""
        self.customers_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.customers_frame, text="Customers")

        # Add Customer Section
        add_cust_frame = ttk.LabelFrame(self.customers_frame, text="Add New Customer", padding="10")
        add_cust_frame.pack(fill="x", padx=10, pady=5)

        # Customer form
        ttk.Label(add_cust_frame, text="First Name:").grid(row=0, column=0, sticky="w", padx=5)
        self.cust_fname_entry = ttk.Entry(add_cust_frame, width=20)
        self.cust_fname_entry.grid(row=0, column=1, padx=5)

        ttk.Label(add_cust_frame, text="Last Name:").grid(row=0, column=2, sticky="w", padx=5)
        self.cust_lname_entry = ttk.Entry(add_cust_frame, width=20)
        self.cust_lname_entry.grid(row=0, column=3, padx=5)

        ttk.Label(add_cust_frame, text="Email:").grid(row=1, column=0, sticky="w", padx=5)
        self.cust_email_entry = ttk.Entry(add_cust_frame, width=30)
        self.cust_email_entry.grid(row=1, column=1, columnspan=2, padx=5)

        ttk.Label(add_cust_frame, text="Phone:").grid(row=1, column=3, sticky="w", padx=5)
        self.cust_phone_entry = ttk.Entry(add_cust_frame, width=20)
        self.cust_phone_entry.grid(row=1, column=4, padx=5)

        ttk.Label(add_cust_frame, text="City:").grid(row=2, column=0, sticky="w", padx=5)
        self.cust_city_entry = ttk.Entry(add_cust_frame, width=20)
        self.cust_city_entry.grid(row=2, column=1, padx=5)

        ttk.Label(add_cust_frame, text="Province:").grid(row=2, column=2, sticky="w", padx=5)
        self.cust_province_entry = ttk.Entry(add_cust_frame, width=20)
        self.cust_province_entry.grid(row=2, column=3, padx=5)

        ttk.Button(add_cust_frame, text="Add Customer", command=self.add_customer).grid(row=2, column=4, padx=10)

        # Customers list
        list_cust_frame = ttk.LabelFrame(self.customers_frame, text="Customer List", padding="10")
        list_cust_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.customers_tree = ttk.Treeview(list_cust_frame,
                                           columns=("ID", "Name", "Email", "Phone", "City", "Orders", "Total_Spent"),
                                           show="headings", height=12)
        for col in ("ID", "Name", "Email", "Phone", "City", "Orders", "Total_Spent"):
            self.customers_tree.heading(col, text=col)
            self.customers_tree.column(col, width=120)

        scrollbar_customers = ttk.Scrollbar(list_cust_frame, orient="vertical", command=self.customers_tree.yview)
        self.customers_tree.configure(yscrollcommand=scrollbar_customers.set)

        self.customers_tree.pack(side="left", fill="both", expand=True)
        scrollbar_customers.pack(side="right", fill="y")

        # Customer buttons
        ttk.Button(self.customers_frame, text="Refresh Customers",
                   command=self.load_customers).pack(pady=10)

    def setup_orders_tab(self):
        """Order management tab"""
        self.orders_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.orders_frame, text="Orders")

        # Create Order Section
        create_order_frame = ttk.LabelFrame(self.orders_frame, text="Create New Order", padding="10")
        create_order_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(create_order_frame, text="Customer ID:").grid(row=0, column=0, sticky="w", padx=5)
        self.order_customer_entry = ttk.Entry(create_order_frame, width=15)
        self.order_customer_entry.grid(row=0, column=1, padx=5)

        ttk.Label(create_order_frame, text="Product ID:").grid(row=0, column=2, sticky="w", padx=5)
        self.order_product_entry = ttk.Entry(create_order_frame, width=15)
        self.order_product_entry.grid(row=0, column=3, padx=5)

        ttk.Label(create_order_frame, text="Quantity:").grid(row=0, column=4, sticky="w", padx=5)
        self.order_quantity_entry = ttk.Entry(create_order_frame, width=10)
        self.order_quantity_entry.grid(row=0, column=5, padx=5)

        ttk.Label(create_order_frame, text="Unit Price:").grid(row=1, column=0, sticky="w", padx=5)
        self.order_price_entry = ttk.Entry(create_order_frame, width=15)
        self.order_price_entry.grid(row=1, column=1, padx=5)

        ttk.Button(create_order_frame, text="Create Order", command=self.create_order).grid(row=1, column=2, padx=10)

        # Order Management Section
        manage_frame = ttk.LabelFrame(self.orders_frame, text="Order Management", padding="10")
        manage_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(manage_frame, text="Order ID:").grid(row=0, column=0, sticky="w", padx=5)
        self.manage_order_id_entry = ttk.Entry(manage_frame, width=15)
        self.manage_order_id_entry.grid(row=0, column=1, padx=5)

        ttk.Label(manage_frame, text="New Status:").grid(row=0, column=2, sticky="w", padx=5)
        self.order_status_combo = ttk.Combobox(manage_frame,
                                               values=["Processing", "Shipped", "Delivered", "Cancelled"],
                                               width=15)
        self.order_status_combo.grid(row=0, column=3, padx=5)

        ttk.Button(manage_frame, text="Update Status", command=self.update_order_status).grid(row=0, column=4, padx=10)
        ttk.Button(manage_frame, text="Get Order Details", command=self.get_order_details).grid(row=0, column=5,
                                                                                                padx=10)

        # Orders list
        orders_list_frame = ttk.LabelFrame(self.orders_frame, text="Orders List", padding="10")
        orders_list_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.orders_tree = ttk.Treeview(orders_list_frame,
                                        columns=(
                                            "Order_ID", "Customer", "Date", "Status", "Total", "Payment", "Delivery"),
                                        show="headings", height=10)
        for col in ("Order_ID", "Customer", "Date", "Status", "Total", "Payment", "Delivery"):
            self.orders_tree.heading(col, text=col)
            self.orders_tree.column(col, width=100)

        scrollbar_orders = ttk.Scrollbar(orders_list_frame, orient="vertical", command=self.orders_tree.yview)
        self.orders_tree.configure(yscrollcommand=scrollbar_orders.set)

        self.orders_tree.pack(side="left", fill="both", expand=True)
        scrollbar_orders.pack(side="right", fill="y")

        ttk.Button(self.orders_frame, text="Refresh Orders", command=self.load_orders).pack(pady=5)

    def setup_inventory_tab(self):
        """Inventory management tab"""
        self.inventory_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.inventory_frame, text="Inventory")

        # Low Stock Alert
        alert_frame = ttk.LabelFrame(self.inventory_frame, text="Low Stock Alert", padding="10")
        alert_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(alert_frame, text="Threshold:").grid(row=0, column=0, sticky="w", padx=5)
        self.stock_threshold_entry = ttk.Entry(alert_frame, width=10)
        self.stock_threshold_entry.insert(0, "5")
        self.stock_threshold_entry.grid(row=0, column=1, padx=5)

        ttk.Button(alert_frame, text="Check Low Stock", command=self.check_low_stock).grid(row=0, column=2, padx=10)

        # Restock Section
        restock_frame = ttk.LabelFrame(self.inventory_frame, text="Restock Products", padding="10")
        restock_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(restock_frame, text="Product ID:").grid(row=0, column=0, sticky="w", padx=5)
        self.restock_product_id_entry = ttk.Entry(restock_frame, width=15)
        self.restock_product_id_entry.grid(row=0, column=1, padx=5)

        ttk.Label(restock_frame, text="Quantity:").grid(row=0, column=2, sticky="w", padx=5)
        self.restock_quantity_entry = ttk.Entry(restock_frame, width=15)
        self.restock_quantity_entry.grid(row=0, column=3, padx=5)

        ttk.Label(restock_frame, text="Notes:").grid(row=0, column=4, sticky="w", padx=5)
        self.restock_notes_entry = ttk.Entry(restock_frame, width=30)
        self.restock_notes_entry.grid(row=0, column=5, padx=5)

        ttk.Button(restock_frame, text="Restock", command=self.restock_product_manual).grid(row=0, column=6, padx=10)

        # Inventory Status
        status_frame = ttk.LabelFrame(self.inventory_frame, text="Inventory Status", padding="10")
        status_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.inventory_tree = ttk.Treeview(status_frame,
                                           columns=("Product_ID", "Product_Name", "Category", "Stock", "Status"),
                                           show="headings", height=15)
        for col in ("Product_ID", "Product_Name", "Category", "Stock", "Status"):
            self.inventory_tree.heading(col, text=col)
            self.inventory_tree.column(col, width=120)

        scrollbar_inventory = ttk.Scrollbar(status_frame, orient="vertical", command=self.inventory_tree.yview)
        self.inventory_tree.configure(yscrollcommand=scrollbar_inventory.set)

        self.inventory_tree.pack(side="left", fill="both", expand=True)
        scrollbar_inventory.pack(side="right", fill="y")

        ttk.Button(self.inventory_frame, text="Refresh Inventory", command=self.load_inventory).pack(pady=5)

    def setup_reports_tab(self):
        """Reports and analytics tab"""
        self.reports_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.reports_frame, text="Reports")

        # Sales Report Section
        sales_frame = ttk.LabelFrame(self.reports_frame, text="Sales Report", padding="10")
        sales_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(sales_frame, text="Start Date (YYYY-MM-DD):").grid(row=0, column=0, sticky="w", padx=5)
        self.start_date_entry = ttk.Entry(sales_frame, width=15)
        self.start_date_entry.insert(0, "2024-01-01")
        self.start_date_entry.grid(row=0, column=1, padx=5)

        ttk.Label(sales_frame, text="End Date (YYYY-MM-DD):").grid(row=0, column=2, sticky="w", padx=5)
        self.end_date_entry = ttk.Entry(sales_frame, width=15)
        self.end_date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.end_date_entry.grid(row=0, column=3, padx=5)

        ttk.Button(sales_frame, text="Generate Sales Report", command=self.generate_sales_report).grid(row=0, column=4,
                                                                                                       padx=10)

        # Customer History Section
        customer_frame = ttk.LabelFrame(self.reports_frame, text="Customer Order History", padding="10")
        customer_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(customer_frame, text="Customer ID:").grid(row=0, column=0, sticky="w", padx=5)
        self.customer_history_id_entry = ttk.Entry(customer_frame, width=15)
        self.customer_history_id_entry.grid(row=0, column=1, padx=5)

        ttk.Button(customer_frame, text="Get Customer History", command=self.get_customer_history).grid(row=0, column=2,
                                                                                                        padx=10)

        # Reports Display
        report_display_frame = ttk.LabelFrame(self.reports_frame, text="Report Results", padding="10")
        report_display_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.report_text = scrolledtext.ScrolledText(report_display_frame, height=20, width=100)
        self.report_text.pack(fill="both", expand=True)

    def setup_admin_tab(self):
        """Admin and maintenance tab"""
        self.admin_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.admin_frame, text="Admin")

        # SQL Query Section
        query_frame = ttk.LabelFrame(self.admin_frame, text="Execute SQL Query", padding="10")
        query_frame.pack(fill="both", expand=True, padx=10, pady=5)

        ttk.Label(query_frame, text="SQL Query:").pack(anchor="w")
        self.sql_query_text = scrolledtext.ScrolledText(query_frame, height=8, width=100)
        self.sql_query_text.pack(fill="both", expand=True, pady=5)

        query_buttons_frame = ttk.Frame(query_frame)
        query_buttons_frame.pack(fill="x", pady=5)

        ttk.Button(query_buttons_frame, text="Execute Query", command=self.execute_sql_query).pack(side="left", padx=5)
        ttk.Button(query_buttons_frame, text="Clear", command=self.clear_sql_query).pack(side="left", padx=5)

        # Sample queries
        sample_frame = ttk.LabelFrame(query_frame, text="Sample Queries", padding="5")
        sample_frame.pack(fill="x", pady=5)

        sample_queries = [
            ("View All Products", "SELECT * FROM VW_ProductCatalog;"),
            ("View Order Summary", "SELECT * FROM VW_OrderSummary;"),
            ("Customer Summary", "SELECT * FROM VW_CustomerSummary;"),
            ("Low Stock Alert", "EXEC SP_GetLowStockProducts @Threshold = 5;"),
            ("Dashboard Stats", "EXEC SP_GetDashboardStats;")
        ]

        for i, (name, query) in enumerate(sample_queries):
            ttk.Button(sample_frame, text=name,
                       command=lambda q=query: self.load_sample_query(q)).grid(row=i // 3, column=i % 3, padx=5, pady=2,
                                                                               sticky="w")

        # Query Results
        results_frame = ttk.LabelFrame(self.admin_frame, text="Query Results", padding="10")
        results_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.query_results_text = scrolledtext.ScrolledText(results_frame, height=15, width=100)
        self.query_results_text.pack(fill="both", expand=True)

    def add_product(self):
        """Add new product"""
        try:
            name = self.product_name_entry.get()
            desc = self.product_desc_entry.get()
            category_text = self.category_combo.get()
            stock = self.initial_stock_entry.get()
            price = self.product_price_entry.get()

            if not all([name, category_text, stock, price]):
                messagebox.showerror("Error", "All fields are required!")
                return

            # Extract category ID from combobox text
            category_id = int(category_text.split(" - ")[0])

            # Call the stored procedure
            self.execute_query(
                "EXEC SP_AddProduct @ProductName=?, @Description=?, @InitialStock=?, @CategoryID=?, @InitialPrice=?",
                (name, desc, int(stock), category_id, float(price)),
                fetch=False
            )

            messagebox.showinfo("Success", "Product added successfully!")
            self.load_products()

            # Clear form
            self.product_name_entry.delete(0, tk.END)
            self.product_desc_entry.delete(0, tk.END)
            self.initial_stock_entry.delete(0, tk.END)
            self.product_price_entry.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to add product:\n{str(e)}")

    def load_categories(self):
        """Load categories for the combobox"""
        try:
            result = self.execute_query("SELECT Category_ID, Category_Name FROM Categories WHERE Is_Active = 1")
            if result:
                categories = [f"{row[0]} - {row[1]}" for row in result]
                self.category_combo['values'] = categories
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load categories:\n{str(e)}")

    def load_products(self):
        """Load products into the treeview"""
        try:
            # Clear existing items
            for item in self.products_tree.get_children():
                self.products_tree.delete(item)

            # Get products from view
            products = self.execute_query("SELECT * FROM VW_ProductCatalog")

            if products:
                for product in products:
                    self.products_tree.insert("", "end", values=product)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load products:\n{str(e)}")

    def restock_product(self):
        """Restock selected product"""
        try:
            selected_item = self.products_tree.selection()
            if not selected_item:
                messagebox.showwarning("Warning", "Please select a product first!")
                return

            item = self.products_tree.item(selected_item[0])
            product_id = item['values'][0]

            # Show restock dialog
            restock_dialog = tk.Toplevel(self.root)
            restock_dialog.title(f"Restock Product ID: {product_id}")

            ttk.Label(restock_dialog, text="Quantity:").grid(row=0, column=0, padx=5, pady=5)
            quantity_entry = ttk.Entry(restock_dialog)
            quantity_entry.grid(row=0, column=1, padx=5, pady=5)

            ttk.Label(restock_dialog, text="Notes:").grid(row=1, column=0, padx=5, pady=5)
            notes_entry = ttk.Entry(restock_dialog)
            notes_entry.grid(row=1, column=1, padx=5, pady=5)

            def perform_restock():
                quantity = quantity_entry.get()
                notes = notes_entry.get()

                if not quantity:
                    messagebox.showerror("Error", "Quantity is required!")
                    return

                try:
                    self.execute_query(
                        "EXEC SP_RestockProduct @ProductID=?, @Quantity=?, @Notes=?",
                        (product_id, int(quantity), notes),
                        fetch=False
                    )

                    messagebox.showinfo("Success", "Product restocked successfully!")
                    restock_dialog.destroy()
                    self.load_products()

                except Exception as e:
                    messagebox.showerror("Error", f"Failed to restock product:\n{str(e)}")

            ttk.Button(restock_dialog, text="Restock", command=perform_restock).grid(row=2, column=0, columnspan=2,
                                                                                     pady=10)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to restock product:\n{str(e)}")

    def add_customer(self):
        """Add new customer"""
        try:
            fname = self.cust_fname_entry.get()
            lname = self.cust_lname_entry.get()
            email = self.cust_email_entry.get()
            phone = self.cust_phone_entry.get()
            city = self.cust_city_entry.get()
            province = self.cust_province_entry.get()

            if not all([fname, lname, email]):
                messagebox.showerror("Error", "First name, last name and email are required!")
                return

            # Insert customer
            self.execute_query(
                "INSERT INTO Users (User_First_Name, User_Last_Name, User_Email, User_Phone, User_Address_City, User_Address_Province) " +
                "VALUES (?, ?, ?, ?, ?, ?)",
                (fname, lname, email, phone, city, province),
                fetch=False
            )

            messagebox.showinfo("Success", "Customer added successfully!")
            self.load_customers()

            # Clear form
            self.cust_fname_entry.delete(0, tk.END)
            self.cust_lname_entry.delete(0, tk.END)
            self.cust_email_entry.delete(0, tk.END)
            self.cust_phone_entry.delete(0, tk.END)
            self.cust_city_entry.delete(0, tk.END)
            self.cust_province_entry.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to add customer:\n{str(e)}")

    def load_customers(self):
        """Load customers into the treeview"""
        try:
            # Clear existing items
            for item in self.customers_tree.get_children():
                self.customers_tree.delete(item)

            # Get customers from view
            customers = self.execute_query("SELECT * FROM VW_CustomerSummary")

            if customers:
                for customer in customers:
                    self.customers_tree.insert("", "end", values=customer)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load customers:\n{str(e)}")

    def create_order(self):
        """Create new order"""
        try:
            customer_id = self.order_customer_entry.get()
            product_id = self.order_product_entry.get()
            quantity = self.order_quantity_entry.get()
            price = self.order_price_entry.get()

            if not all([customer_id, product_id, quantity, price]):
                messagebox.showerror("Error", "All fields are required!")
                return

            # Create JSON for products
            products_json = json.dumps([{
                "ProductID": int(product_id),
                "Quantity": int(quantity),
                "Price": float(price)
            }])

            # Call stored procedure
            result = self.execute_query(
                "EXEC SP_CreateOrder @UserID=?, @ProductsJSON=?",
                (int(customer_id), products_json)
            )

            if result:
                order_id = result[0][0]
                messagebox.showinfo("Success", f"Order created successfully! Order ID: {order_id}")
                self.load_orders()

                # Clear form
                self.order_customer_entry.delete(0, tk.END)
                self.order_product_entry.delete(0, tk.END)
                self.order_quantity_entry.delete(0, tk.END)
                self.order_price_entry.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to create order:\n{str(e)}")

    def load_orders(self):
        """Load orders into the treeview"""
        try:
            # Clear existing items
            for item in self.orders_tree.get_children():
                self.orders_tree.delete(item)

            # Get orders from view
            orders = self.execute_query("SELECT * FROM VW_OrderSummary ORDER BY Order_Date DESC")

            if orders:
                for order in orders:
                    self.orders_tree.insert("", "end", values=order)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load orders:\n{str(e)}")

    def update_order_status(self):
        """Update order status"""
        try:
            order_id = self.manage_order_id_entry.get()
            new_status = self.order_status_combo.get()

            if not all([order_id, new_status]):
                messagebox.showerror("Error", "Order ID and status are required!")
                return

            # Call stored procedure
            self.execute_query(
                "EXEC SP_UpdateOrderStatus @OrderID=?, @NewStatus=?",
                (int(order_id), new_status),
                fetch=False
            )

            messagebox.showinfo("Success", "Order status updated successfully!")
            self.load_orders()

        except Exception as e:
            messagebox.showerror("Error", f"Failed to update order status:\n{str(e)}")

    def get_order_details(self):
        """Get detailed order information"""
        try:
            order_id = self.manage_order_id_entry.get()

            if not order_id:
                messagebox.showerror("Error", "Order ID is required!")
                return

            # Call stored procedure
            cursor = self.connection.cursor()
            cursor.execute("EXEC SP_GetOrderDetails @OrderID=?", (int(order_id),))

            # Get order header
            order_header = cursor.fetchone()

            # Get order items
            cursor.nextset()
            order_items = cursor.fetchall()

            cursor.close()

            # Display results
            details_window = tk.Toplevel(self.root)
            details_window.title(f"Order Details - ID: {order_id}")

            # Header frame
            header_frame = ttk.LabelFrame(details_window, text="Order Header", padding="10")
            header_frame.pack(fill="x", padx=10, pady=5)

            if order_header:
                ttk.Label(header_frame, text=f"Order ID: {order_header[0]}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Date: {order_header[1]}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Status: {order_header[2]}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Total: PKR {order_header[3]:,.2f}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Customer: {order_header[4]}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Email: {order_header[5]}").pack(anchor="w")
                ttk.Label(header_frame, text=f"Phone: {order_header[6]}").pack(anchor="w")

            # Items frame
            items_frame = ttk.LabelFrame(details_window, text="Order Items", padding="10")
            items_frame.pack(fill="both", expand=True, padx=10, pady=5)

            items_tree = ttk.Treeview(items_frame,
                                      columns=(
                                          "Product_ID", "Product_Name", "Quantity", "Unit_Price", "Line_Total"),
                                      show="headings", height=5)

            for col in ("Product_ID", "Product_Name", "Quantity", "Unit_Price", "Line_Total"):
                items_tree.heading(col, text=col)
                items_tree.column(col, width=100)

            scrollbar = ttk.Scrollbar(items_frame, orient="vertical", command=items_tree.yview)
            items_tree.configure(yscrollcommand=scrollbar.set)

            items_tree.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")

            if order_items:
                for item in order_items:
                    items_tree.insert("", "end", values=item)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to get order details:\n{str(e)}")

    def check_low_stock(self):
        """Check for low stock items"""
        try:
            threshold = self.stock_threshold_entry.get()

            if not threshold:
                messagebox.showerror("Error", "Threshold is required!")
                return

            # Clear existing items
            for item in self.inventory_tree.get_children():
                self.inventory_tree.delete(item)

            # Call stored procedure
            low_stock_items = self.execute_query(
                "EXEC SP_GetLowStockProducts @Threshold=?",
                (int(threshold),)
            )

            if low_stock_items:
                for item in low_stock_items:
                    self.inventory_tree.insert("", "end", values=item)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to check low stock:\n{str(e)}")

    def restock_product_manual(self):
        """Restock product from manual entry"""
        try:
            product_id = self.restock_product_id_entry.get()
            quantity = self.restock_quantity_entry.get()
            notes = self.restock_notes_entry.get()

            if not all([product_id, quantity]):
                messagebox.showerror("Error", "Product ID and quantity are required!")
                return

            # Call stored procedure
            self.execute_query(
                "EXEC SP_RestockProduct @ProductID=?, @Quantity=?, @Notes=?",
                (int(product_id), int(quantity), notes),
                fetch=False
            )

            messagebox.showinfo("Success", "Product restocked successfully!")
            self.load_inventory()

            # Clear form
            self.restock_product_id_entry.delete(0, tk.END)
            self.restock_quantity_entry.delete(0, tk.END)
            self.restock_notes_entry.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to restock product:\n{str(e)}")

    def load_inventory(self):
        """Load inventory status"""
        try:
            # Clear existing items
            for item in self.inventory_tree.get_children():
                self.inventory_tree.delete(item)

            # Get inventory status
            inventory = self.execute_query("SELECT * FROM VW_InventoryStatus")

            if inventory:
                for item in inventory:
                    self.inventory_tree.insert("", "end", values=item)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load inventory:\n{str(e)}")

    def generate_sales_report(self):
        """Generate sales report"""
        try:
            start_date = self.start_date_entry.get()
            end_date = self.end_date_entry.get()

            if not all([start_date, end_date]):
                messagebox.showerror("Error", "Both dates are required!")
                return

            # Call stored procedure
            sales_report = self.execute_query(
                "EXEC SP_GetSalesReport @StartDate=?, @EndDate=?",
                (start_date, end_date)
            )

            # Display results
            self.report_text.delete(1.0, tk.END)

            if sales_report:
                # Create a formatted report
                report_str = f"Sales Report from {start_date} to {end_date}\n\n"
                report_str += "{:<20} {:<30} {:<10} {:<15} {:<15}\n".format(
                    "Category", "Product", "Sold", "Revenue", "Avg Price")
                report_str += "-" * 90 + "\n"

                total_revenue = 0
                for row in sales_report:
                    report_str += "{:<20} {:<30} {:<10} PKR {:<12,.2f} PKR {:<12,.2f}\n".format(
                        row[0], row[1], row[2], row[3], row[4])
                    total_revenue += row[3]

                report_str += "\nTotal Revenue: PKR {:,.2f}\n".format(total_revenue)

                self.report_text.insert(tk.END, report_str)
            else:
                self.report_text.insert(tk.END, "No sales data found for the selected period.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to generate sales report:\n{str(e)}")

    def get_customer_history(self):
        """Get customer order history"""
        try:
            customer_id = self.customer_history_id_entry.get()

            if not customer_id:
                messagebox.showerror("Error", "Customer ID is required!")
                return

            # Call stored procedure
            history = self.execute_query(
                "EXEC SP_GetCustomerOrderHistory @UserID=?",
                (int(customer_id),)
            )

            # Display results
            self.report_text.delete(1.0, tk.END)

            if history:
                # Create a formatted report
                report_str = f"Order History for Customer ID: {customer_id}\n\n"
                report_str += "{:<10} {:<15} {:<15} {:<15} {:<15} {:<20}\n".format(
                    "Order ID", "Date", "Status", "Total", "Payment", "Delivery")
                report_str += "-" * 90 + "\n"

                for row in history:
                    report_str += "{:<10} {:<15} {:<15} PKR {:<12,.2f} {:<15} {:<20}\n".format(
                        row[0], str(row[1]), row[2], row[3], row[4], row[5])

                self.report_text.insert(tk.END, report_str)
            else:
                self.report_text.insert(tk.END, "No order history found for this customer.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to get customer history:\n{str(e)}")

    def execute_sql_query(self):
        """Execute custom SQL query"""
        try:
            query = self.sql_query_text.get("1.0", tk.END).strip()

            if not query:
                messagebox.showerror("Error", "Please enter a SQL query!")
                return

            # Execute query
            result = self.execute_query(query)

            # Display results
            self.query_results_text.delete(1.0, tk.END)

            if result:
                # For SELECT queries, display as table
                if query.strip().upper().startswith(('SELECT', 'EXEC', 'WITH')):
                    # Convert to pandas DataFrame for nice formatting
                    try:
                        import pandas as pd
                        df = pd.DataFrame.from_records(result)
                        self.query_results_text.insert(tk.END, df.to_string())
                    except:
                        # Fallback if pandas not available
                        for row in result:
                            self.query_results_text.insert(tk.END, str(row) + "\n")
                else:
                    self.query_results_text.insert(tk.END, "Query executed successfully.")
            else:
                self.query_results_text.insert(tk.END, "No results returned.")

        except Exception as e:
            self.query_results_text.delete(1.0, tk.END)
            self.query_results_text.insert(tk.END, f"Error executing query:\n{str(e)}")

    def clear_sql_query(self):
        """Clear SQL query text"""
        self.sql_query_text.delete("1.0", tk.END)

    def load_sample_query(self, query):
        """Load sample query into the editor"""
        self.sql_query_text.delete("1.0", tk.END)
        self.sql_query_text.insert(tk.END, query)


def main():
    root = tk.Tk()
    app = LTHRPKDatabaseGUI(root)
    try:
        root.mainloop()
    finally:
        app.stop_refresh = True
        # Close all connections in the pool
        while not app.connection_pool.empty():
            try:
                conn = app.connection_pool.get_nowait()
                conn.close()
            except:
                pass


if __name__ == "__main__":
    print(pyodbc.drivers())
    main()
