-- LTHR PK Database Management System
-- Complete SQL Server Implementation for Database Systems Course
-- Author: Student Implementation based on ERD Document

USE master;
GO

-- Drop database if exists
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'LTHR_PK')
    DROP DATABASE LTHR_PK;
GO

-- Create Database
CREATE DATABASE DB_Project;
GO

USE DB_Project;
GO

-- ============================================================================
-- TABLE CREATION
-- ============================================================================

-- Categories Table
CREATE TABLE Categories (
    Category_ID INT IDENTITY(1,1) PRIMARY KEY,
    Category_Name VARCHAR(50) NOT NULL UNIQUE,
    Category_Description TEXT,
    Created_Date DATETIME DEFAULT GETDATE(),
    Is_Active BIT DEFAULT 1
);

-- Users Table
CREATE TABLE Users (
    User_ID INT IDENTITY(1,1) PRIMARY KEY,
    User_First_Name VARCHAR(50) NOT NULL,
    User_Last_Name VARCHAR(50) NOT NULL,
    User_Email VARCHAR(100) NOT NULL UNIQUE,
    User_Phone VARCHAR(15),
    User_Address_City VARCHAR(50),
    User_Address_Province VARCHAR(50),
    User_Password_Hash VARCHAR(255),
    Created_Date DATETIME DEFAULT GETDATE(),
    Is_Active BIT DEFAULT 1
);

-- Products Table
CREATE TABLE Products (
    Product_ID INT IDENTITY(1,1) PRIMARY KEY,
    Product_Name VARCHAR(100) NOT NULL,
    Product_Description TEXT,
    Product_Stock INT DEFAULT 0 CHECK (Product_Stock >= 0),
    Category_ID INT NOT NULL,
    Created_Date DATETIME DEFAULT GETDATE(),
    Is_Active BIT DEFAULT 1,
    FOREIGN KEY (Category_ID) REFERENCES Categories(Category_ID)
);

-- Price History Table
CREATE TABLE Price_History (
    Price_ID INT IDENTITY(1,1) PRIMARY KEY,
    Product_ID INT NOT NULL,
    Price_Value DECIMAL(10,2) NOT NULL CHECK (Price_Value > 0),
    Price_Start_Date DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE),
    Price_End_Date DATE NULL,
    Created_Date DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (Product_ID) REFERENCES Products(Product_ID)
);

-- Orders Table
CREATE TABLE Orders (
    Order_ID INT IDENTITY(1,1) PRIMARY KEY,
    User_ID INT NOT NULL,
    Order_Date DATETIME DEFAULT GETDATE(),
    Order_Status VARCHAR(20) DEFAULT 'Processing' CHECK (Order_Status IN ('Processing', 'Shipped', 'Delivered', 'Cancelled')),
    Order_Total DECIMAL(10,2) DEFAULT 0,
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID)
);

-- Order Products Junction Table
CREATE TABLE Order_Products (
    Order_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Product_Quantity INT NOT NULL CHECK (Product_Quantity > 0),
    Unit_Price DECIMAL(10,2) NOT NULL CHECK (Unit_Price > 0),
    Line_Total AS (Product_Quantity * Unit_Price) PERSISTED,
    PRIMARY KEY (Order_ID, Product_ID),
    FOREIGN KEY (Order_ID) REFERENCES Orders(Order_ID),
    FOREIGN KEY (Product_ID) REFERENCES Products(Product_ID)
);

-- Payments Table
CREATE TABLE Payments (
    Payment_ID INT IDENTITY(1,1) PRIMARY KEY,
    Order_ID INT NOT NULL UNIQUE,
    Payment_Method VARCHAR(20) CHECK (Payment_Method IN ('Credit Card', 'JazzCash', 'Bank Transfer', 'COD')),
    Payment_Amount DECIMAL(10,2) NOT NULL CHECK (Payment_Amount > 0),
    Payment_Status VARCHAR(20) DEFAULT 'Pending' CHECK (Payment_Status IN ('Pending', 'Completed', 'Refunded', 'Failed')),
    Payment_Date DATETIME DEFAULT GETDATE(),
    Transaction_ID VARCHAR(100),
    FOREIGN KEY (Order_ID) REFERENCES Orders(Order_ID)
);

-- Delivery Table
CREATE TABLE Deliveries (
    Delivery_ID INT IDENTITY(1,1) PRIMARY KEY,
    Order_ID INT NOT NULL UNIQUE,
    Courier_Name VARCHAR(50),
    Tracking_Number VARCHAR(50),
    Delivery_Status VARCHAR(20) DEFAULT 'Dispatched' CHECK (Delivery_Status IN ('Dispatched', 'In Transit', 'Delivered', 'Failed')),
    Shipped_Date DATETIME,
    Delivered_Date DATETIME,
    Delivery_Address TEXT,
    FOREIGN KEY (Order_ID) REFERENCES Orders(Order_ID)
);

-- Reviews Table
CREATE TABLE Reviews (
    Review_ID INT IDENTITY(1,1) PRIMARY KEY,
    User_ID INT NOT NULL,
    Product_ID INT NOT NULL,
    Review_Rating TINYINT CHECK (Review_Rating BETWEEN 1 AND 5),
    Review_Text TEXT,
    Review_Date DATETIME DEFAULT GETDATE(),
    Is_Approved BIT DEFAULT 0,
    FOREIGN KEY (User_ID) REFERENCES Users(User_ID),
    FOREIGN KEY (Product_ID) REFERENCES Products(Product_ID)
);

-- ============================================================================
-- HISTORY/AUDIT TABLES
-- ============================================================================

-- Order History Table
CREATE TABLE Order_History (
    History_ID INT IDENTITY(1,1) PRIMARY KEY,
    Order_ID INT NOT NULL,
    Old_Status VARCHAR(20),
    New_Status VARCHAR(20),
    Changed_By VARCHAR(50),
    Change_Date DATETIME DEFAULT GETDATE(),
    Change_Reason TEXT
);

-- Product Stock History
CREATE TABLE Product_Stock_History (
    History_ID INT IDENTITY(1,1) PRIMARY KEY,
    Product_ID INT NOT NULL,
    Old_Stock INT,
    New_Stock INT,
    Change_Type VARCHAR(20), -- 'Sale', 'Restock', 'Adjustment'
    Change_Date DATETIME DEFAULT GETDATE(),
    Reference_Order_ID INT NULL,
    Notes TEXT
);

-- User Activity Log
CREATE TABLE User_Activity_Log (
    Log_ID INT IDENTITY(1,1) PRIMARY KEY,
    User_ID INT NOT NULL,
    Activity_Type VARCHAR(50),
    Activity_Description TEXT,
    IP_Address VARCHAR(45),
    Activity_Date DATETIME DEFAULT GETDATE()
);

-- ============================================================================
-- INDEXES
-- ============================================================================

-- Clustered Indexes (Primary Keys are automatically clustered)

-- Non-Clustered Indexes
CREATE NONCLUSTERED INDEX IX_Users_Email ON Users(User_Email);
CREATE NONCLUSTERED INDEX IX_Users_Phone ON Users(User_Phone);
CREATE NONCLUSTERED INDEX IX_Products_Category ON Products(Category_ID);
CREATE NONCLUSTERED INDEX IX_Products_Stock ON Products(Product_Stock);
CREATE NONCLUSTERED INDEX IX_Orders_User ON Orders(User_ID);
CREATE NONCLUSTERED INDEX IX_Orders_Date ON Orders(Order_Date);
CREATE NONCLUSTERED INDEX IX_Orders_Status ON Orders(Order_Status);
CREATE NONCLUSTERED INDEX IX_OrderProducts_Product ON Order_Products(Product_ID);
CREATE NONCLUSTERED INDEX IX_Reviews_Product ON Reviews(Product_ID);
CREATE NONCLUSTERED INDEX IX_Reviews_User ON Reviews(User_ID);
CREATE NONCLUSTERED INDEX IX_PriceHistory_Product ON Price_History(Product_ID);
CREATE NONCLUSTERED INDEX IX_Payments_Status ON Payments(Payment_Status);
CREATE NONCLUSTERED INDEX IX_Deliveries_Status ON Deliveries(Delivery_Status);

-- Composite Indexes
CREATE NONCLUSTERED INDEX IX_Orders_User_Date ON Orders(User_ID, Order_Date);
CREATE NONCLUSTERED INDEX IX_Products_Category_Stock ON Products(Category_ID, Product_Stock);

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Trigger 1: Update Order Total when Order_Products change
CREATE TRIGGER TR_UpdateOrderTotal
ON Order_Products
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Update order totals for affected orders
    UPDATE o
    SET Order_Total = ISNULL((
        SELECT SUM(Product_Quantity * Unit_Price)
        FROM Order_Products op
        WHERE op.Order_ID = o.Order_ID
    ), 0)
    FROM Orders o
    WHERE o.Order_ID IN (
        SELECT DISTINCT Order_ID FROM inserted
        UNION
        SELECT DISTINCT Order_ID FROM deleted
    );
END;
GO

-- Trigger 2: Log stock changes and update stock when orders are placed
CREATE TRIGGER TR_UpdateProductStock
ON Order_Products
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Update product stock
    UPDATE p
    SET Product_Stock = Product_Stock - i.Product_Quantity
    FROM Products p
    INNER JOIN inserted i ON p.Product_ID = i.Product_ID;
    
    -- Log stock changes
    INSERT INTO Product_Stock_History (Product_ID, Old_Stock, New_Stock, Change_Type, Reference_Order_ID)
    SELECT 
        i.Product_ID,
        p.Product_Stock + i.Product_Quantity,
        p.Product_Stock,
        'Sale',
        i.Order_ID
    FROM inserted i
    INNER JOIN Products p ON p.Product_ID = i.Product_ID;
END;
GO

-- Trigger 3: Log order status changes
CREATE TRIGGER TR_LogOrderStatusChange
ON Orders
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    IF UPDATE(Order_Status)
    BEGIN
        INSERT INTO Order_History (Order_ID, Old_Status, New_Status, Changed_By)
        SELECT 
            i.Order_ID,
            d.Order_Status,
            i.Order_Status,
            SYSTEM_USER
        FROM inserted i
        INNER JOIN deleted d ON i.Order_ID = d.Order_ID
        WHERE i.Order_Status != d.Order_Status;
    END
END;
GO

-- Trigger 4: Prevent negative stock
CREATE TRIGGER TR_PreventNegativeStock
ON Products
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    
    IF EXISTS (SELECT 1 FROM inserted WHERE Product_Stock < 0)
    BEGIN
        RAISERROR('Stock cannot be negative', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

-- Procedure 1: Create new order with products
CREATE PROCEDURE SP_CreateOrder
    @UserID INT,
    @ProductsJSON NVARCHAR(MAX) -- JSON format: [{"ProductID":1,"Quantity":2,"Price":1500.00}]
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        
        DECLARE @OrderID INT;
        
        -- Create order
        INSERT INTO Orders (User_ID) VALUES (@UserID);
        SET @OrderID = SCOPE_IDENTITY();
        
        -- Parse JSON and insert order products
        INSERT INTO Order_Products (Order_ID, Product_ID, Product_Quantity, Unit_Price)
        SELECT 
            @OrderID,
            JSON_VALUE(value, '$.ProductID'),
            JSON_VALUE(value, '$.Quantity'),
            JSON_VALUE(value, '$.Price')
        FROM OPENJSON(@ProductsJSON);
        
        SELECT @OrderID AS OrderID, 'Order created successfully' AS Message;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Procedure 2: Get order details
CREATE PROCEDURE SP_GetOrderDetails
    @OrderID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        o.Order_ID,
        o.Order_Date,
        o.Order_Status,
        o.Order_Total,
        u.User_First_Name + ' ' + u.User_Last_Name AS Customer_Name,
        u.User_Email,
        u.User_Phone
    FROM Orders o
    INNER JOIN Users u ON o.User_ID = u.User_ID
    WHERE o.Order_ID = @OrderID;
    
    -- Order items
    SELECT 
        op.Product_ID,
        p.Product_Name,
        op.Product_Quantity,
        op.Unit_Price,
        op.Line_Total
    FROM Order_Products op
    INNER JOIN Products p ON op.Product_ID = p.Product_ID
    WHERE op.Order_ID = @OrderID;
END;
GO

-- Procedure 3: Update order status
CREATE PROCEDURE SP_UpdateOrderStatus
    @OrderID INT,
    @NewStatus VARCHAR(20),
    @Reason TEXT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        UPDATE Orders 
        SET Order_Status = @NewStatus
        WHERE Order_ID = @OrderID;
        
        IF @Reason IS NOT NULL
        BEGIN
            UPDATE Order_History 
            SET Change_Reason = @Reason
            WHERE Order_ID = @OrderID 
            AND Change_Date = (SELECT MAX(Change_Date) FROM Order_History WHERE Order_ID = @OrderID);
        END
        
        SELECT 'Order status updated successfully' AS Message;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

-- Procedure 4: Get low stock products
CREATE PROCEDURE SP_GetLowStockProducts
    @Threshold INT = 5
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        p.Product_ID,
        p.Product_Name,
        p.Product_Stock,
        c.Category_Name,
        CASE 
            WHEN p.Product_Stock = 0 THEN 'Out of Stock'
            WHEN p.Product_Stock <= @Threshold THEN 'Low Stock'
        END AS Stock_Status
    FROM Products p
    INNER JOIN Categories c ON p.Category_ID = c.Category_ID
    WHERE p.Product_Stock <= @Threshold AND p.Is_Active = 1
    ORDER BY p.Product_Stock ASC;
END;
GO

-- Procedure 5: Add product with initial price
CREATE PROCEDURE SP_AddProduct
    @ProductName VARCHAR(100),
    @Description TEXT,
    @InitialStock INT,
    @CategoryID INT,
    @InitialPrice DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;
        
        DECLARE @ProductID INT;
        
        INSERT INTO Products (Product_Name, Product_Description, Product_Stock, Category_ID)
        VALUES (@ProductName, @Description, @InitialStock, @CategoryID);
        
        SET @ProductID = SCOPE_IDENTITY();
        
        INSERT INTO Price_History (Product_ID, Price_Value)
        VALUES (@ProductID, @InitialPrice);
        
        SELECT @ProductID AS ProductID, 'Product added successfully' AS Message;
        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Procedure 6: Process payment
CREATE PROCEDURE SP_ProcessPayment
    @OrderID INT,
    @PaymentMethod VARCHAR(20),
    @PaymentAmount DECIMAL(10,2),
    @TransactionID VARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        INSERT INTO Payments (Order_ID, Payment_Method, Payment_Amount, Payment_Status, Transaction_ID)
        VALUES (@OrderID, @PaymentMethod, @PaymentAmount, 'Completed', @TransactionID);
        
        -- Update order status to shipped if payment successful
        UPDATE Orders 
        SET Order_Status = 'Shipped' 
        WHERE Order_ID = @OrderID AND Order_Status = 'Processing';
        
        SELECT 'Payment processed successfully' AS Message;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

-- Procedure 7: Update delivery status
CREATE PROCEDURE SP_UpdateDeliveryStatus
    @OrderID INT,
    @DeliveryStatus VARCHAR(20),
    @TrackingNumber VARCHAR(50) = NULL,
    @CourierName VARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF NOT EXISTS (SELECT 1 FROM Deliveries WHERE Order_ID = @OrderID)
    BEGIN
        INSERT INTO Deliveries (Order_ID, Delivery_Status, Tracking_Number, Courier_Name, Shipped_Date)
        VALUES (@OrderID, @DeliveryStatus, @TrackingNumber, @CourierName, GETDATE());
    END
    ELSE
    BEGIN
        UPDATE Deliveries 
        SET 
            Delivery_Status = @DeliveryStatus,
            Tracking_Number = ISNULL(@TrackingNumber, Tracking_Number),
            Courier_Name = ISNULL(@CourierName, Courier_Name),
            Delivered_Date = CASE WHEN @DeliveryStatus = 'Delivered' THEN GETDATE() ELSE Delivered_Date END
        WHERE Order_ID = @OrderID;
    END
    
    -- Update order status if delivered
    IF @DeliveryStatus = 'Delivered'
    BEGIN
        UPDATE Orders SET Order_Status = 'Delivered' WHERE Order_ID = @OrderID;
    END
    
    SELECT 'Delivery status updated successfully' AS Message;
END;
GO

-- Procedure 8: Get customer order history
CREATE PROCEDURE SP_GetCustomerOrderHistory
    @UserID INT,
    @StartDate DATE = NULL,
    @EndDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        o.Order_ID,
        o.Order_Date,
        o.Order_Status,
        o.Order_Total,
        p.Payment_Status,
        d.Delivery_Status,
        d.Tracking_Number
    FROM Orders o
    LEFT JOIN Payments p ON o.Order_ID = p.Order_ID
    LEFT JOIN Deliveries d ON o.Order_ID = d.Order_ID
    WHERE o.User_ID = @UserID
    AND (@StartDate IS NULL OR o.Order_Date >= @StartDate)
    AND (@EndDate IS NULL OR o.Order_Date <= @EndDate)
    ORDER BY o.Order_Date DESC;
END;
GO

-- Procedure 9: Restock product
CREATE PROCEDURE SP_RestockProduct
    @ProductID INT,
    @Quantity INT,
    @Notes TEXT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        DECLARE @OldStock INT;
        SELECT @OldStock = Product_Stock FROM Products WHERE Product_ID = @ProductID;
        
        UPDATE Products 
        SET Product_Stock = Product_Stock + @Quantity
        WHERE Product_ID = @ProductID;
        
        INSERT INTO Product_Stock_History (Product_ID, Old_Stock, New_Stock, Change_Type, Notes)
        VALUES (@ProductID, @OldStock, @OldStock + @Quantity, 'Restock', @Notes);
        
        SELECT 'Product restocked successfully' AS Message;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

-- Procedure 10: Get sales report
CREATE PROCEDURE SP_GetSalesReport
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        c.Category_Name,
        p.Product_Name,
        SUM(op.Product_Quantity) AS Total_Sold,
        SUM(op.Line_Total) AS Total_Revenue,
        AVG(op.Unit_Price) AS Avg_Price
    FROM Order_Products op
    INNER JOIN Products p ON op.Product_ID = p.Product_ID
    INNER JOIN Categories c ON p.Category_ID = c.Category_ID
    INNER JOIN Orders o ON op.Order_ID = o.Order_ID
    WHERE o.Order_Date BETWEEN @StartDate AND @EndDate
    AND o.Order_Status != 'Cancelled'
    GROUP BY c.Category_Name, p.Product_Name, p.Product_ID
    ORDER BY Total_Revenue DESC;
END;
GO

-- Procedure 11: Add product review
CREATE PROCEDURE SP_AddProductReview
    @UserID INT,
    @ProductID INT,
    @Rating TINYINT,
    @ReviewText TEXT
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Check if user has purchased this product
    IF EXISTS (
        SELECT 1 FROM Order_Products op
        INNER JOIN Orders o ON op.Order_ID = o.Order_ID
        WHERE o.User_ID = @UserID AND op.Product_ID = @ProductID
        AND o.Order_Status = 'Delivered'
    )
    BEGIN
        INSERT INTO Reviews (User_ID, Product_ID, Review_Rating, Review_Text)
        VALUES (@UserID, @ProductID, @Rating, @ReviewText);
        
        SELECT 'Review added successfully' AS Message;
    END
    ELSE
    BEGIN
        SELECT 'You can only review products you have purchased' AS Message;
    END
END;
GO

-- Procedure 12: Get product reviews
CREATE PROCEDURE SP_GetProductReviews
    @ProductID INT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        r.Review_ID,
        u.User_First_Name + ' ' + u.User_Last_Name AS Customer_Name,
        r.Review_Rating,
        r.Review_Text,
        r.Review_Date,
        r.Is_Approved
    FROM Reviews r
    INNER JOIN Users u ON r.User_ID = u.User_ID
    WHERE r.Product_ID = @ProductID
    ORDER BY r.Review_Date DESC;
    
    -- Summary statistics
    SELECT 
        COUNT(*) AS Total_Reviews,
        AVG(CAST(Review_Rating AS FLOAT)) AS Average_Rating,
        COUNT(CASE WHEN Review_Rating = 5 THEN 1 END) AS Five_Star,
        COUNT(CASE WHEN Review_Rating = 4 THEN 1 END) AS Four_Star,
        COUNT(CASE WHEN Review_Rating = 3 THEN 1 END) AS Three_Star,
        COUNT(CASE WHEN Review_Rating = 2 THEN 1 END) AS Two_Star,
        COUNT(CASE WHEN Review_Rating = 1 THEN 1 END) AS One_Star
    FROM Reviews
    WHERE Product_ID = @ProductID AND Is_Approved = 1;
END;
GO

-- ============================================================================
-- VIEWS
-- ============================================================================

-- View 1: Product catalog with current prices
CREATE VIEW VW_ProductCatalog AS
SELECT 
    p.Product_ID,
    p.Product_Name,
    p.Product_Description,
    p.Product_Stock,
    c.Category_Name,
    ph.Price_Value AS Current_Price,
    CASE 
        WHEN p.Product_Stock = 0 THEN 'Out of Stock'
        WHEN p.Product_Stock <= 5 THEN 'Low Stock'
        ELSE 'In Stock'
    END AS Stock_Status,
    p.Created_Date
FROM Products p
INNER JOIN Categories c ON p.Category_ID = c.Category_ID
INNER JOIN Price_History ph ON p.Product_ID = ph.Product_ID
WHERE p.Is_Active = 1 
AND ph.Price_End_Date IS NULL;
GO

-- View 2: Order summary
CREATE VIEW VW_OrderSummary AS
SELECT 
    o.Order_ID,
    u.User_First_Name + ' ' + u.User_Last_Name AS Customer_Name,
    u.User_Email,
    o.Order_Date,
    o.Order_Status,
    o.Order_Total,
    p.Payment_Status,
    d.Delivery_Status,
    d.Tracking_Number,
    COUNT(op.Product_ID) AS Items_Count
FROM Orders o
INNER JOIN Users u ON o.User_ID = u.User_ID
LEFT JOIN Payments p ON o.Order_ID = p.Order_ID
LEFT JOIN Deliveries d ON o.Order_ID = d.Order_ID
LEFT JOIN Order_Products op ON o.Order_ID = op.Order_ID
GROUP BY o.Order_ID, u.User_First_Name, u.User_Last_Name, u.User_Email,
         o.Order_Date, o.Order_Status, o.Order_Total, p.Payment_Status,
         d.Delivery_Status, d.Tracking_Number;
GO

-- View 3: Customer summary
CREATE VIEW VW_CustomerSummary AS
SELECT 
    u.User_ID,
    u.User_First_Name + ' ' + u.User_Last_Name AS Full_Name,
    u.User_Email,
    u.User_Phone,
    u.User_Address_City,
    u.User_Address_Province,
    COUNT(o.Order_ID) AS Total_Orders,
    ISNULL(SUM(o.Order_Total), 0) AS Total_Spent,
    MAX(o.Order_Date) AS Last_Order_Date,
    u.Created_Date AS Registration_Date
FROM Users u
LEFT JOIN Orders o ON u.User_ID = o.User_ID
WHERE u.Is_Active = 1
GROUP BY u.User_ID, u.User_First_Name, u.User_Last_Name, u.User_Email,
         u.User_Phone, u.User_Address_City, u.User_Address_Province, u.Created_Date;
GO

-- View 4: Inventory status
CREATE VIEW VW_InventoryStatus AS
SELECT 
    c.Category_Name,
    COUNT(p.Product_ID) AS Total_Products,
    SUM(p.Product_Stock) AS Total_Stock,
    COUNT(CASE WHEN p.Product_Stock = 0 THEN 1 END) AS Out_Of_Stock,
    COUNT(CASE WHEN p.Product_Stock <= 5 AND p.Product_Stock > 0 THEN 1 END) AS Low_Stock,
    AVG(CAST(p.Product_Stock AS FLOAT)) AS Avg_Stock_Per_Product
FROM Categories c
LEFT JOIN Products p ON c.Category_ID = p.Category_ID AND p.Is_Active = 1
GROUP BY c.Category_ID, c.Category_Name;
GO

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function 1: Get current product price
CREATE FUNCTION FN_GetCurrentPrice(@ProductID INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Price DECIMAL(10,2);
    
    SELECT @Price = Price_Value
    FROM Price_History
    WHERE Product_ID = @ProductID AND Price_End_Date IS NULL;
    
    RETURN ISNULL(@Price, 0);
END;
GO

-- Function 2: Calculate order total
CREATE FUNCTION FN_CalculateOrderTotal(@OrderID INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Total DECIMAL(10,2);
    
    SELECT @Total = SUM(Product_Quantity * Unit_Price)
    FROM Order_Products
    WHERE Order_ID = @OrderID;
    
    RETURN ISNULL(@Total, 0);
END;
GO

-- ============================================================================
-- SAMPLE DATA INSERTION
-- ============================================================================

-- Insert Categories
INSERT INTO Categories (Category_Name, Category_Description) VALUES
('Wallets', 'Premium leather wallets with RFID protection'),
('Belts', 'Handcrafted leather belts for men and women'),
('Bags', 'Leather bags including laptop bags, totes, and briefcases'),
('Accessories', 'Leather accessories like keychains and cardholders');

-- Insert Users
INSERT INTO Users (User_First_Name, User_Last_Name, User_Email, User_Phone, User_Address_City, User_Address_Province) VALUES
('Ahmed', 'Ali', 'ahmed.ali@email.com', '+92-300-1234567', 'Lahore', 'Punjab'),
('Fatima', 'Khan', 'fatima.khan@email.com', '+92-301-2345678', 'Karachi', 'Sindh'),
('Muhammad', 'Hassan', 'muhammad.hassan@email.com', '+92-302-3456789', 'Islamabad', 'ICT'),
('Ayesha', 'Sheikh', 'ayesha.sheikh@email.com', '+92-303-4567890', 'Lahore', 'Punjab'),
('Omar', 'Malik', 'omar.malik@email.com', '+92-304-5678901', 'Faisalabad', 'Punjab');

-- Insert Products
INSERT INTO Products (Product_Name, Product_Description, Product_Stock, Category_ID) VALUES
('Classic Leather Wallet', 'Handcrafted full-grain leather wallet with RFID blocking', 25, 1),
('Slim Bifold Wallet', 'Minimalist design wallet perfect for everyday use', 30, 1),
('Executive Belt Black', 'Premium black leather belt for formal occasions', 20, 2),
('Casual Brown Belt', 'Versatile brown leather belt for casual wear', 15, 2),
('Laptop Bag 15inch', 'Professional leather laptop bag with multiple compartments', 12, 3),
('Leather Messenger Bag', 'Vintage style messenger bag for work and travel', 8, 3),
('Leather Keychain', 'Handcrafted leather keychain with metal ring', 50, 4),
('Card Holder', 'Slim card holder for minimalist carry', 35, 4);

-- Insert Price History
INSERT INTO Price_History (Product_ID, Price_Value) VALUES
(1, 2500.00), (2, 1800.00), (3, 3200.00), (4, 2800.00),
(5, 8500.00), (6, 6500.00), (7, 450.00), (8, 1200.00);

-- ============================================================================
-- DEMONSTRATION TRANSACTIONS
-- ============================================================================

-- Demo Transaction 1: Complete order process
BEGIN TRANSACTION;
    EXEC SP_CreateOrder @UserID = 1, @ProductsJSON = '[{"ProductID":1,"Quantity":1,"Price":2500.00},{"ProductID":7,"Quantity":2,"Price":450.00}]';
    DECLARE @OrderID INT = @@IDENTITY;
    EXEC SP_ProcessPayment @OrderID = @OrderID, @PaymentMethod = 'Credit Card', @PaymentAmount = 3400.00, @TransactionID = 'TXN123456';
    EXEC SP_UpdateDeliveryStatus @OrderID = @OrderID, @DeliveryStatus = 'Dispatched', @TrackingNumber = 'TRK789012', @CourierName = 'TCS';
COMMIT TRANSACTION;
